import awsSDK from "aws-sdk";
const glue = new awsSDK.Glue();

export const handler = async (event) => {
  const bucket = event.Records[0].s3.bucket.name;
  const key = event.Records[0].s3.object.key;
  const jobName = "TransformRawDataJob";
  console.log(`Processing file: s3://${bucket}/${key}`);

  const params = {
    JobName: jobName,
    Arguments: {
      "--input_path": `s3://${bucket}/${key}`,
    },
  };

  try {
    const response = await glue.startJobRun(params).promise();
    console.log(
      `Started Glue job ${jobName} with JobRunId: ${response.JobRunId}`
    );
    return {
      statusCode: 200,
      body: JSON.stringify(
        `Started Glue job ${jobName} with JobRunId: ${response.JobRunId}`
      ),
    };
  } catch (error) {
    console.error("Error starting Glue job:", error);
    throw new Error(`Failed to start job: ${error.message}`);
  }
};
